export const SITE = {
  name: "Talha Ansari",
  firstName: "Talha",
  lastName: "Ansari",
  title: "Senior MERN Stack Engineer",
  roles: [
    "Senior MERN Stack Engineer",
    "React & Next.js Specialist",
    "UI/UX-minded Developer",
    "Cloud & API Architect",
  ],
  tagline:
    // "I design and engineer fast, elegant, production-grade web products — blending pixel-perfect interfaces with resilient full-stack systems.",
    "I build modern, fast, and scalable MERN stack applications — combining pixel-perfect React interfaces with powerful Node.js, Express.js, and MongoDB backends to deliver seamless digital experiences.",
  email: "talhaanxaritn@gmail.com",
  phone: "+92 400 262 456",
  location: "Karachi, Pakistan",
  resumeUrl: "/resume.pdf",
  socials: {
    github: "https://github.com/talha-anxari",
    linkedin:
      "https://www.linkedin.com/in/muhammad-talha-naeem-ansari-894841281",
    instagram: "https://www.instagram.com/talhaolive4240/",
    dribbble: "https://dribbble.com",
  },
} as const;

export const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Experience", href: "#experience" },
  { label: "Services", href: "#services" },
  { label: "Contact", href: "#contact" },
] as const;
